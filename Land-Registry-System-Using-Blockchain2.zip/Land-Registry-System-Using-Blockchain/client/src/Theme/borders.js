import colors from "./colors"
const lightBorder = `1px solid ${colors.lightBorderColor}`

export {lightBorder}
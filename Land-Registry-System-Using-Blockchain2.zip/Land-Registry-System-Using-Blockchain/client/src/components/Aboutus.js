import React from "react";

const Aboutus =() =>{
  return(

  <div className="App">About Us Page</div>)

};
export default Aboutus;
